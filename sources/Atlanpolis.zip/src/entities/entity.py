import pygame as pg


class PhysicsEntity:
    def __init__(self, pos, velocity = (100, 100), hitbox = (8, 15)) -> None:
        self.hitbox = pg.FRect(*pos, *hitbox)
        self.velocity = pg.Vector2()
        self.speed = pg.Vector2(velocity)
        self.movement = [False, False, False, False]
        self.collisions = {'up': False, 'down': False, 'left': False, 'right': False}

    def horizontal_collision(self, frame_movement, tilemap):
        for rect in tilemap.physics_rects_around(self.hitbox.center):
            if self.hitbox.colliderect(rect):
                if frame_movement[0] > 0:
                    self.hitbox.right = rect.left
                    self.collisions['right'] = True
                if frame_movement[0] < 0:
                    self.hitbox.left = rect.right
                    self.collisions['left'] = True
    
    def vertical_collision(self, frame_movement, tilemap):
        for rect in tilemap.physics_rects_around(self.hitbox.center):
            if self.hitbox.colliderect(rect):
                if frame_movement[1] > 0:
                    self.hitbox.bottom = rect.top
                    self.collisions['down'] = True
                if frame_movement[1] < 0:
                    self.hitbox.top = rect.bottom
                    self.collisions['up'] = True
