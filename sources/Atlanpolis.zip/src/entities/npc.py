import pygame as pg

from entities.entity import PhysicsEntity


class Npc(PhysicsEntity):
    def __init__(self, game, entity_type, pos, oxigen = 10) -> None:
        super().__init__(pos)

        self.entity_type = entity_type
        self.Game = game

        self.gulpin = self.Game.assets.load_sound('gulpin', 0.07)
        self.drop = self.Game.assets.load_sound('drop', 0.07)
        self.last_gulp = self.Game.assets.load_sound('last_gulp', 0.07)

        self.flip = False

        self.oxigen = oxigen
        self.affect_gravity = True
        self.alive = True
        self.grabable = True
        self.player = None
        self.following = pg.Vector2(self.hitbox.topleft)
        self.current_animation = self.Game.assets.animated[self.entity_type]['idle'].copy()

    def kill(self, enitites_list):
        if int(self.oxigen) == -5:
            if self.player:
                self.set_unfollow()
            self.grabable = False
            self.current_animation = self.Game.assets.animated[self.entity_type]['dead'].copy()
            self.gulpin.stop()
            self.last_gulp.play()
        elif self.oxigen <= -15:
            enitites_list.remove(self)
            return True

    def set_follow(self, player):
        if self.grabable:
            if int(self.oxigen) <= -5:
                self.current_animation = self.Game.assets.animated[self.entity_type]['dead'].copy()
            elif int(self.oxigen) <= 1:
                self.current_animation = self.Game.assets.animated[self.entity_type]['dying'].copy()
                self.gulpin.play()
            else:
                self.current_animation = self.Game.assets.animated[self.entity_type]['grabbed'].copy()
            self.player = player
            self.affect_gravity = False

    def set_unfollow(self):
        self.player.ungrab()
        self.player = None
        self.affect_gravity = True
        self.following = pg.Vector2(self.hitbox.topleft)
        
    def update(self, dt, tilemap, *args):
        self.collisions = {'up': False, 'down': False, 'left': False, 'right': False}
        direction = pg.Vector2(self.movement[1] - self.movement[0], self.movement[3] - self.movement[2])
        frame_movement =  (direction.x + self.velocity.x, direction.y + self.velocity.y)

        if frame_movement[0] >= 0:
            self.flip = False
        if frame_movement[0] < 0:
            self.flip = True

        if direction.magnitude() != 0:
            direction.normalize()

        if self.player:
            self.following.x = self.player.hitbox.left - 4 
            if frame_movement[0] > 0:
                self.following.x -= 4
            else:
                self.following.x += 16

            self.following.y = self.player.hitbox.top

            if abs(self.player.hitbox.centerx - self.hitbox.centerx) > 48 or abs(self.player.hitbox.centery  - self.hitbox.centery) > 48:
                self.set_unfollow()
                if int(self.oxigen) <= -5:
                    self.current_animation = self.Game.assets.animated[self.entity_type]['dead'].copy()
                elif int(self.oxigen) <= 1:
                    self.current_animation = self.Game.assets.animated[self.entity_type]['dying'].copy()
                    self.gulpin.play()
                if int(self.oxigen) > 5:
                    self.current_animation = self.Game.assets.animated[self.entity_type]['idle'].copy()

        self.velocity.x = 0.08*(self.following.x - self.hitbox.centerx) * self.speed.x * dt
        self.hitbox.centerx += self.velocity.x
        if not self.player: self.horizontal_collision(frame_movement, tilemap)

        self.velocity.y = 0.1*(self.following.y  - self.hitbox.y) * self.speed.y * dt
        self.hitbox.centery += self.velocity.y if self.player else frame_movement[1] * dt
        if not self.player: self.vertical_collision(frame_movement, tilemap)

        if self.affect_gravity:
            self.velocity.y += 24 * self.speed.y * dt

        if -30 >= (self.hitbox.centery) <= -25 and self.player:
            self.set_unfollow()
            self.current_animation = self.Game.assets.animated[self.entity_type]['idle'].copy()
            self.hitbox.centery = -40
            self.affect_gravity = False
            self.grabable = False
            self.oxigen = 1000
            self.drop.play()
            return True

        self.oxigen -= 1 * dt
        if self.oxigen <= 0:
            self.alive = False

        if int(self.oxigen) == 1:
             self.current_animation = self.Game.assets.animated[self.entity_type]['dying'].copy()
             self.gulpin.play()

        self.current_animation.update(dt)
        if int(self.oxigen) == -5:
            return False
    
    def render(self, display, offset):
        surf, _, w, h = self.current_animation.get_current_data(self.flip, False)
        display.blit(
            surf,
            (
                self.hitbox.centerx - w/2 - offset[0],
                self.hitbox.centery - h/2 - offset[1]
            )
        )
         
    def render_hitbox(self, display, offset):
        _, _, w, h = self.current_animation.get_current_data(False, False)
        pg.draw.rect(
            display,
            (200, 40, 40),
            (
                self.hitbox.x - offset[0],
                self.hitbox.y - offset[1],
                self.hitbox.w,
                self.hitbox.h
                ),
            1
        )


