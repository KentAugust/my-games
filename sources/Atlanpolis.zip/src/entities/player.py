import pygame as pg

from entities.entity import PhysicsEntity


class Player(PhysicsEntity):
    def __init__(self, game, entity_type, pos) -> None:
        super().__init__(pos, (160, 160), (15, 15))

        self.entity_type = entity_type
        self.Game = game

        self.flip = False

        self.alive = True

        self.grab = False
        self.grabbing = False
        self.grabed_entity = None
        self.current_animation = self.Game.assets.animated[self.entity_type]['idle'].copy()

    def controll(self, event):
        match event.type:
            case pg.KEYDOWN:
                match event.key:
                    case pg.K_LEFT:
                        self.movement[0] = True
                    case pg.K_RIGHT:
                        self.movement[1] = True
                    case pg.K_UP:
                        self.movement[2] = True
                    case pg.K_DOWN:
                        self.movement[3] = True
                    case pg.K_x:
                        self.grab = True
            case pg.KEYUP:
                match event.key:
                    case pg.K_LEFT:
                        self.movement[0] = False
                    case pg.K_RIGHT:
                        self.movement[1] = False
                    case pg.K_UP:
                        self.movement[2] = False
                    case pg.K_DOWN:
                        self.movement[3] = False
    
    def update(self, dt, tilemap, entities):
        self.collisions = {'up': False, 'down': False, 'left': False, 'right': False}

        direction = pg.Vector2(self.movement[1] - self.movement[0], self.movement[3] - self.movement[2])
        if direction.magnitude() != 0:
            direction.normalize()
        
        frame_movement = (direction.x + self.velocity.x, direction.y + self.velocity.y)

        if frame_movement[0] > 0:
            self.flip = False
        if frame_movement[0] < 0:
            self.flip = True

        
        
        self.velocity.x = direction.x * self.speed.x * dt
        self.hitbox.x += self.velocity.x
        self.horizontal_collision(frame_movement, tilemap)

        self.velocity.y = direction.y * self.speed.y * dt
        self.hitbox.y += self.velocity.y
        self.vertical_collision(frame_movement, tilemap)

        self.grab_npc(entities)
        self.current_animation.update(dt)
    
    def render(self, display, offset):
        surf, _, w, h = self.current_animation.get_current_data(self.flip, False)
        display.blit(
            surf,
            (
                self.hitbox.centerx - w/2 - offset[0],
                self.hitbox.centery - h/2 - offset[1]
            )
        )
    
    def render_hitbox(self, display, offset):
        _, _, w, h = self.current_animation.get_current_data(self.flip, False)
        pg.draw.rect(
            display,
            (200, 40, 40),
            (
                self.hitbox.x - offset[0],
                self.hitbox.y - offset[1],
                self.hitbox.w,
                self.hitbox.h
                ),
            1
        )


    def grab_npc(self, entities):
        if self.grab:
            for entity in entities:
                if self.hitbox.colliderect(entity.hitbox) and not self.grabbing and entity.entity_type != self.entity_type:
                    self.grabed_entity = entity
                    self.grabed_entity.set_follow(self)
                    self.grabbing = True
                    break
                self.grab = False

    def ungrab(self):
        self.grab = False
        self.grabbing = False
        self.grabed_entity = None
