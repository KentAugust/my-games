import logging

import pygame as pg

from timers import Cronometer
from utils import load_img, clip, swap_color, flip_img, load_sound

logger = logging.getLogger()


class Assets:
    def __init__(self, general_path, config):
        self.config = config

        self.GENERAL_PATH = general_path

        self.static_imgs = {}
        self.variable_imgs = {}
        self.animated = {}
        self.fonts = {}
        self.music = {}
        self.sfx = {}
    
    def load_static_img(self, name):
        filename = self.config['static_img'][name]
        extend_path = self.config['static_img_extra_path'].get(name, '')
        path = ''.join([self.GENERAL_PATH, extend_path, filename])
        self.static_imgs[name] = load_img(path)

    def load_variable_img(self, name, variant = 0):
        files_list = sorted(self.config['variable_img'][name])
        extend_path = self.config['variable_img_extra_path'].get(name, '')

        if name not in self.variable_imgs:
            self.variable_imgs[name] = {}

        path = '/'.join([self.GENERAL_PATH, extend_path, name, files_list[variant]])
        self.variable_imgs[name][variant] = load_img(path)

    def load_animation(self, category, name, loop=False):
        extend_path = self.config['animated_extra_path'].get(category, '')

        if category not in self.animated:
            self.animated[category] = {}
        frames_list = self.config['animated'][category][name]

        animation_data = []
        for frame in frames_list:
            path = '/'.join([self.GENERAL_PATH, extend_path, category, name, frame[0]])
            surf = load_img(path)
            animation_data.append((surf, frame[1], surf.get_width(), surf.get_height()))
        self.animated[category][name] = Animation(animation_data, loop)

    def load_font(self, name, spacing=1):
        filename = self.config['fonts_img'][name]
        extend_path = self.config['fonts_extra_path'].get(name, '')
        path = '/'.join([self.GENERAL_PATH, extend_path, filename])
        self.fonts[name] = Font(path, spacing)

    def load_sound(self, name, volumen = 1):
        extend_path = self.config['sound_extra_path'].get(name, '')
        path = '/'.join([self.GENERAL_PATH, extend_path, self.config['sound_effects'][name]])
        sound = load_sound(path)
        sound.set_volume(volumen)
        return sound


class Animation:
    def __init__(self, animation_data: list[tuple[pg.Surface, int, int, int]], loop = False):
        self.animation_data = animation_data
        self.loop = loop
        self.ended = False
        self.frame = 0
        self.cronometer = Cronometer()

    def update(self, dt):
        self.cronometer.update(dt)
        if self.cronometer.current_time >= self.animation_data[self.frame][1]:
            self.frame += 1
            if self.frame >= len(self.animation_data):
                if self.loop:
                    self.frame = 0
                else:
                    self.frame -= 1
                    self.ended = True
            self.cronometer.reset()

    def get_current_data(self, flip_x, flip_y):
        return flip_img(self.animation_data[self.frame][0], flip_x, flip_y), *self.animation_data[self.frame][1:]

    def stop(self):
        self.start_time = 0
        self.frame = 0
        self.ended = False
    
    def copy(self):
        return Animation(self.animation_data, self.loop)


class Font:
    CHARS = [
        'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
        'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',
        '.', '-', ',', ':', '+', "'", '!', '?', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '(', ')', '/', '_', '=', '\\', '[', ']',
        '*', '"', '<', '>', '¡']

    def __init__(self, path, spacing=1, colorkey = (0, 0, 0)):
        self._path = path
        font_img = load_img(path, set_colorkey=False)

        self.spacing = spacing
        self.characters = {}
        self.colorkey = colorkey
        
        current_chart_width = 0
        char_count = 0
        for x in range(font_img.get_width()):
            color = font_img.get_at((x, 0))
            if color[0] == 127:
                char_img = clip(font_img, x - current_chart_width, 0, current_chart_width, font_img.get_height())
                char_img.set_colorkey(self.colorkey)
                self.characters[self.CHARS[char_count]] = char_img
                char_count += 1
                current_chart_width = 0
            elif color[0] != 0:
                self.orginal_color = (color[0], 0, 0) #temp
                self.actual_color = (color[0], 0, 0) #temp
                current_chart_width += 1
            else:
                current_chart_width += 1
        self.spacing_width = self.characters['A'].get_width()

    def change_color(self, old_color, new_color):
        if new_color != self.actual_color:
            for char in self.characters:
                swap_img = swap_color(self.characters[char], old_color, new_color)
                swap_img.set_colorkey(self.colorkey)
                self.characters[char] = swap_img
            self.actual_color = new_color
        return self

    def render(self, surf, text, pos):
        x_offset = 0
        for char in text:
            if char != ' ':
                try:
                    surf.blit(self.characters[char], (pos[0] + x_offset, pos[1]))
                    x_offset += self.characters[char].get_width() + self.spacing
                except KeyError:
                    x_offset += self.spacing + self.spacing_width
            else:
                x_offset += self.spacing + self.spacing_width
    
    def copy(self):
        return Font(self._path, self.spacing, self.colorkey).change_color(self.orginal_color, self.actual_color)
