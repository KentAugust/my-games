class Cronometer:
    def __init__(self) -> None:
        self._current_time = 0
        self._start_time = 0

    def update(self, dt):
        self._start_time += dt
        self._current_time = self._start_time * 1000
    
    @property
    def current_time(self):
        return self._current_time
    
    def reset(self):
        self._start_time = 0
        self._current_time = 0
