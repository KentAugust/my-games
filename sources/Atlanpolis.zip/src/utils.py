import pathlib
import tomllib
import pygame as pg

def load_shader(path):
    n_path = pathlib.Path(path)
    try:
        with open(n_path, 'r') as f:
            data = f.read()
    except FileNotFoundError:
        return None
    
    return data

def load_toml(path: str) -> dict:
    n_path = pathlib.Path(path)
    try:
        with open(n_path, mode="rb") as fp:
            data = tomllib.load(fp)
    except FileNotFoundError:
        return None
    
    return data

def load_img(path, colorkey = (0, 0, 0), set_colorkey = True):
    n_path = pathlib.Path(path)
    img = pg.image.load(n_path).convert()
    if set_colorkey:
        img.set_colorkey(colorkey)
    return img

def clip(surf: pg.Surface, x: int, y: int, width: int, height: int):
    handle_surf = surf.copy()
    clip_rect = pg.Rect(x, y, width, height)
    handle_surf.set_clip(clip_rect)
    img = surf.subsurface(handle_surf.get_clip())
    return img

def swap_color(surf, old_color, new_color):
    img_copy = pg.Surface(surf.get_size())
    img_copy.fill(new_color)
    surf.set_colorkey(old_color)
    img_copy.blit(surf, (0, 0))
    return img_copy

def flip_img(surf, flip_x, flip_y):
    return pg.transform.flip(surf, flip_x, flip_y)

def load_sound(path):
    n_path = pathlib.Path(path)
    if pg.mixer.get_init():
        return pg.mixer.Sound(n_path)
