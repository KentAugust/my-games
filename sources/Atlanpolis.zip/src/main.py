import sys
import time

import logging
import moderngl
import pygame as pg

from array import array
from utils import load_shader, load_toml
from assets_loader import Assets

from scenes import Level, MainMenu, TransitionScreen

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger()

window_sizes = [(320, 180), (640, 360), (960, 540), (1280, 720)]


class Game:
    config = load_toml('data/config/general.toml')

    def __init__(self) -> None:
        self.is_fullscreen = False

        pg.init()
        self._init_window()
        self._init_assets()
        self._init_shaders()
        self._init_scenes()
        
        self.clock = pg.Clock()
        self.assets.load_static_img('icon')
        pg.display.set_icon(self.assets.static_imgs['icon'])

    def _init_window(self):
        self.config['desktop_sizes'] = pg.display.get_desktop_sizes()
        for size in sorted(window_sizes, reverse=True):
            if size not in set(self.config['desktop_sizes']):
                self.config['desktop_sizes'].append(size)

        self.update_win_size(2)
        logger.debug(f"All window sizes {self.config['desktop_sizes']}")
        pg.display.set_caption(f"{self.config['title']} v{'.'.join( [str(n) for n in self.config['version']] )}")
        
    def _init_shaders(self):
        self.ctx = moderngl.create_context()
        quad_buffer = self.ctx.buffer(data=array('f', [
            -1.0,  1.0, 0.0, 0.0,
             1.0,  1.0, 1.0, 0.0,
            -1.0, -1.0, 0.0, 1.0,
             1.0, -1.0, 1.0, 1.0,
        ]))

        vert_shader = load_shader('data/shaders/vertex.vert')
        frag_shader = load_shader('data/shaders/fragment.frag')

        self.program = self.ctx.program(vertex_shader=vert_shader, fragment_shader=frag_shader)
        self.render = self.ctx.vertex_array(self.program, [(quad_buffer, '2f 2f', 'vertPos', 'texCoord')])

    def _init_scenes(self):
        self.scenes = {
            'main_menu': {
                'class': MainMenu,
                'args': {'game': self}
            },
            'level': {
                'class': Level,
                'args': {'game': self}
            },
            'transition': {
                'class': TransitionScreen,
                'args': {'game': self}
            }
        }
        self.change_scene('main_menu')
    
    def _init_assets(self):
        self.assets = Assets(self.config['res_path'], load_toml('data/config/resources.toml'))
        self.assets.load_font('small')
        self.assets.load_font('large')
        self.assets.fonts['small'].change_color((255, 0, 0), (140, 170, 86))
        self.assets.fonts['large'].change_color((255, 0, 0), (140, 170, 86))

    def change_scene(self, name):
        if name in self.scenes:
            logger.info(f"Changing to '{name}' scene")
            scene_class = self.scenes[name]['class']
            self.actual_scene = scene_class(**self.scenes[name]['args'])
        else:
            logger.debug(f"Not found '{name}' scene")

    def surf_to_texture(self, surf):
        tex = self.ctx.texture(surf.get_size(), 4)
        tex.filter = (moderngl.NEAREST, moderngl.NEAREST)
        tex.swizzle = 'BGRA'
        tex.write(surf.get_view('1'))
        return tex

    def run(self):
        logger.info('Runing the game...')

        prev_time = time.time()
        while True:
            dt = time.time() - prev_time
            prev_time = time.time()

            self.actual_scene.handle_events()
            self.actual_scene.update(dt)
            self.actual_scene.render(self.display)

            self.clock.tick(60)

    def update_win_size(self, size_option: int):
        try:
            size = self.config['desktop_sizes'][size_option]
        except IndexError:
            size = (1280, 720)
        
        try:
            if size == pg.display.get_window_size():
                return
        except pg.error:
            logger.info(f"Initializing window with size {size}")
        
        if not self.is_fullscreen:
            self.config['window_size'] = self.config.get('current_win_size', (1280, 720))

        if size_option == 0:
            if not self.is_fullscreen:
                pg.display.toggle_fullscreen()
                self.display = pg.Surface((1280, 720))
            self.is_fullscreen = not self.is_fullscreen
            self.config['current_win_size'] = pg.display.get_window_size()
            return
        
        if self.is_fullscreen:
            pg.display.toggle_fullscreen()

        self.is_fullscreen = False if self.is_fullscreen else False

        self.win_screen = pg.display.set_mode(size, pg.OPENGL | pg.DOUBLEBUF)
        self.display = pg.Surface(size)

        self.config['current_win_size'] = pg.display.get_window_size()
    
    def toggle_fullscreen(self):
        logger.debug('toggle full screen')
        if not self.is_fullscreen:
            self.update_win_size(0)
        else:
            for i, size in enumerate(self.config['desktop_sizes']):
                if self.config['window_size'] == size:
                    self.update_win_size(i)
                    return
    
    def exit(self):
        logger.info('Exiting the game...')
        pg.quit()
        sys.exit()


if __name__ == '__main__':
    Game().run()
