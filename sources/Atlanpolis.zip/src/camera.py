import pygame as pg


class Camera:
    def __init__(self, canvas_size) -> None:
        self.offset = pg.Vector2()
        self.canvas_size = canvas_size

    def update(self, target_pos, inerce = [1, 1]):
        self.offset.x += (target_pos[0] - self.canvas_size[0]/2 - self.offset.x)/inerce[0]
        self.offset.y += (target_pos[1] - self.canvas_size[1]/2 - self.offset.y)/inerce[1]
    
    def render(self, display, elements):
        for element in sorted(elements, key= lambda elem: elem.hitbox.bottom):
            element.render(display, self.offset)

    def render_hitboxes(self, display, elements):
        for element in sorted(elements, key= lambda elem: elem.hitbox.centery):
            element.render_hitbox(display, self.offset)
    
    def render_bg(self, display, backgronds):
        for bg, offx, offy in backgronds:
            display.blit(bg, (-100 - offx * self.offset.x, offy * self.offset.y))
