import random

import moderngl
import pygame as pg

from camera import Camera
from timers import Cronometer
from entities.player import Player
from entities.npc import Npc
from tilemap import Tilemap


class Level:
    def __init__(self, game) -> None:
        self.Game = game
        self.canvas = pg.Surface(self.Game.config['canvas_size'])
        self.bg_canvas = pg.Surface(self.Game.config['canvas_size'])

        self.Game.assets.fonts['clock'] = self.Game.assets.fonts['large'].copy()
        self.Game.assets.load_sound('gulpin', 0.1)

        self.backgrounds = self._init_background()
        self.tilemap = Tilemap(self.Game)
        self.tilemap.load('data/maps/map_1.json')

        self.Game.program['display'] = 0

        self.cam = Camera(self.canvas.get_size())

        self.player = Player(self.Game, 'player', (random.randint(128, 1064), 16))
        self.entities = []
        self.entities.append(self.player)

        self.total_npc = 15
        self.drownings = 0
        self.spawn_entities('npc', self.total_npc)

        self.cronometer = Cronometer()
        self.play_time = 90 #seconds
        self.score = 0

    def _init_background(self):
        backgrounds = []
        for i in range(7):
            self.Game.assets.load_variable_img('background', i)
            offx = 0.04 * i * random.random() if i > 3 else 0
            offy = 0.01 if i > 3 else 0
            backgrounds.append([self.Game.assets.variable_imgs['background'][i], offx, offy])
        return backgrounds

    def handle_events(self):
        for event in pg.event.get():
            match event.type:
                case pg.QUIT:
                    self.Game.exit()
                case pg.KEYDOWN:
                    match event.key:
                        case pg.K_F11:
                            self.Game.toggle_fullscreen()
                        case pg.K_ESCAPE:
                            self.Game.change_scene('main_menu')
                        case pg.K_SPACE:
                            if self.play_time - self.cronometer.current_time * 0.001 < -1:
                                self.Game.change_scene('main_menu')
            self.player.controll(event)

    def update(self, dt):
        self.cronometer.update(dt)
        if self.play_time - self.cronometer.current_time * 0.001 > 0:
            for entity in self.entities:
                helped = entity.update(dt, self.tilemap, self.entities)
                if helped:
                    self.score += 1
                    self.total_npc -= 1

            self.cam.update(self.player.hitbox.center, (20, 20))
            self.check_alive()

        self.Game.program['deltatime'] = self.cronometer.current_time

    def render(self, display):
        self.canvas.fill((20, 20, 20))
        self.bg_canvas.fill((20, 20, 20))

        self.cam.render_bg(self.bg_canvas, self.backgrounds)
        self.canvas.blit(self.bg_canvas, (0, 0))
        self.tilemap.render(self.canvas, self.cam.offset)
        self.cam.render(self.canvas, self.entities)
        # self.cam.render_hitboxes(self.canvas, self.entities) #hitboxes

        self.render_clock()

        display.blit(pg.transform.scale(self.canvas, display.get_size()), (0, 0))

        frame_tex = self.Game.surf_to_texture(display)
        frame_tex.use(0)
        self.Game.render.render(mode=moderngl.TRIANGLE_STRIP)


        pg.display.flip()
        frame_tex.release()

    def render_clock(self):
        subtract = self.play_time - self.cronometer.current_time * 0.001
        if subtract < 10:
            self.Game.assets.fonts['clock'].change_color((140, 170, 86), (171, 7, 23))

        if subtract >= 0:
            self.Game.assets.fonts['clock'].render(self.canvas, f"{subtract:.0f}s", (self.Game.config['canvas_size'][0]//2, 20))
        else:
            self.Game.assets.fonts['clock'].render(self.canvas, f"Finish!", (self.Game.config['canvas_size'][0]//2-20, 20))
            self.Game.assets.fonts['large'].render(self.canvas, f"press space to go to menu!", (self.Game.config['canvas_size'][0] // 2 - 80, self.Game.config['canvas_size'][1] - 80))

        self.Game.assets.fonts['small'].render(self.canvas, f"{self.Game.clock.get_fps():.0f} fps", (20, 20))
        self.Game.assets.fonts['small'].render(self.canvas, f"People left: {self.total_npc}", (10, 230))
        self.Game.assets.fonts['small'].render(self.canvas, f"Saved: {self.score}", (10, 240))
        self.Game.assets.fonts['small'].render(self.canvas, f"Drowned: {self.drownings}", (10, 250))

    def scale_mouse_pos(self):
        canvas_size = self.canvas.get_size()
        display_size = self.Game.display.get_size()
        mouse_pos = pg.mouse.get_pos()
        return mouse_pos[0]/display_size[0] * canvas_size[0], mouse_pos[1]/display_size[1] * canvas_size[1]
    
    def spawn_entities(self, entity_type, quantity):
        for i in range(quantity):
            while True:
                pos = (random.randint(128, 1100), random.randint(100, 500))
                if not self.tilemap.solid_check(pos):
                    break
            
            match entity_type:
                case 'npc':
                    self.entities.append(Npc(
                        game=self.Game,
                        entity_type=f"npc_{random.randint(1, 4)}",
                        pos=pos,
                        oxigen=random.randint(45, 90)
                    ))
                    self.entities[-1].horizontal_collision((1, 0), self.tilemap)
                    self.entities[-1].vertical_collision((1, 1), self.tilemap)

    def check_alive(self):
        for entity in self.entities.copy():
            if not entity.alive:
                drown = entity.kill(self.entities)
                if drown:
                    self.drownings += 1
                    self.total_npc -= 1


class MainMenu:
    def __init__(self, game) -> None:
        self.Game = game
        self.Game.program['display'] = 0
        self.Game.assets.load_static_img('title')

        self.canvas = pg.Surface(self.Game.config['canvas_size'])
        self.backgrounds = self._init_background()

        self.cam = Camera(self.canvas.get_size())
        self.bubble = self.Game.assets.load_sound('bubble', 0.07)

    def _init_background(self):
        backgrounds = []
        for i in range(7):
            self.Game.assets.load_variable_img('background', i)
            offx = 0.04 * i * random.random() if i > 3 else 0
            offy = 0.01 if i > 3 else 0
            backgrounds.append([self.Game.assets.variable_imgs['background'][i], offx, offy])
        return backgrounds

    def handle_events(self):
        for event in pg.event.get():
            match event.type:
                case pg.QUIT:
                    self.Game.exit()
                case pg.KEYDOWN:
                    match event.key:
                        case pg.K_F11:
                            self.Game.toggle_fullscreen()
                        case pg.K_SPACE:
                            self.bubble.play()
                            self.Game.change_scene('transition')

    def update(self, dt):
        self.cam.update(self.scale_mouse_pos(), (20, 20))
        self.Game.program['deltatime'] = dt * 1000

    def render(self, display):
        self.canvas.fill((20, 20, 20))

        self.cam.render_bg(self.canvas, self.backgrounds)
        self.Game.assets.fonts['small'].render(self.canvas, f"{self.Game.config['title']} v{'.'.join( [str(n) for n in self.Game.config['version']] )}", (10, self.Game.config['canvas_size'][1] - 15))
        self.Game.assets.fonts['small'].render(self.canvas, f"{self.Game.config['developer']} / {self.Game.config['artist']}", (self.Game.config['canvas_size'][0] - 80, self.Game.config['canvas_size'][1] - 15))
        self.Game.assets.fonts['large'].render(self.canvas, f"press space to start!", (self.Game.config['canvas_size'][0] // 2 - 80, self.Game.config['canvas_size'][1] - 100))

        display.blit(pg.transform.scale(self.canvas, display.get_size()), (0, 0))

        display.blit(
            self.Game.assets.static_imgs['title'],
            (display.get_width()//2-self.Game.assets.static_imgs['title'].get_width()//2, 40)
        )

        self.Game.assets.fonts['large'].render(display, f"{self.Game.clock.get_fps():.0f} fps", (20, 20))

        frame_tex = self.Game.surf_to_texture(display)
        frame_tex.use(0)
        self.Game.render.render(mode=moderngl.TRIANGLE_STRIP)

        pg.display.flip()
        frame_tex.release()

    def scale_mouse_pos(self):
        canvas_size = self.canvas.get_size()
        display_size = self.Game.display.get_size()
        mouse_pos = pg.mouse.get_pos()
        return mouse_pos[0]/display_size[0] * canvas_size[0], mouse_pos[1]/display_size[1] * canvas_size[1]


class TransitionScreen:
    def __init__(self, game) -> None:
        self.Game = game
        self.Game.program['display'] = 0

        self.canvas = pg.Surface(self.Game.config['canvas_size'])
        self.backgrounds = self._init_background()

        self.cam = Camera(self.canvas.get_size())
        self.cronometer = Cronometer()

    def _init_background(self):
        backgrounds = []
        for i in range(4):
            self.Game.assets.load_variable_img('background', i)
            offx = 0.04 * i * random.random() if i > 3 else 0
            offy = 0.01 if i > 3 else 0
            backgrounds.append([self.Game.assets.variable_imgs['background'][i], offx, offy])
        return backgrounds

    def handle_events(self):
        for event in pg.event.get():
            match event.type:
                case pg.QUIT:
                    self.Game.exit()
                case pg.KEYDOWN:
                    match event.key:
                        case pg.K_F11:
                            self.Game.toggle_fullscreen()

    def update(self, dt):
        self.Game.program['deltatime'] = dt * 1000

        for i in range(9):
            self.Game.assets.load_variable_img('coral', i)
        self.Game.assets.load_variable_img('bubbles', 0)

        self.Game.assets.load_animation('player', 'idle', True)
        self.Game.assets.load_animation('npc_1', 'idle', True)
        self.Game.assets.load_animation('npc_1', 'grabbed', True)
        self.Game.assets.load_animation('npc_1', 'dying', True)
        self.Game.assets.load_animation('npc_1', 'dead', True)

        self.Game.assets.load_animation('npc_2', 'idle', True)
        self.Game.assets.load_animation('npc_2', 'grabbed', True)
        self.Game.assets.load_animation('npc_2', 'dying', True)
        self.Game.assets.load_animation('npc_2', 'dead', True)

        self.Game.assets.load_animation('npc_3', 'idle', True)
        self.Game.assets.load_animation('npc_3', 'grabbed', True)
        self.Game.assets.load_animation('npc_3', 'dying', True)
        self.Game.assets.load_animation('npc_3', 'dead', True)

        self.Game.assets.load_animation('npc_4', 'idle', True)
        self.Game.assets.load_animation('npc_4', 'grabbed', True)
        self.Game.assets.load_animation('npc_4', 'dying', True)
        self.Game.assets.load_animation('npc_4', 'dead', True)


        self.cronometer.update(dt)
        if self.cronometer.current_time * 0.001 >= 3:
            self.Game.change_scene('level')

    def render(self, display):
        self.canvas.fill((20, 20, 20))

        self.cam.render_bg(self.canvas, self.backgrounds)
        self.Game.assets.fonts['large'].render(self.canvas, f"Use arrow keys to move and x to grab", (self.Game.config['canvas_size'][0] // 2 - 125, self.Game.config['canvas_size'][1] - 120))

        display.blit(pg.transform.scale(self.canvas, display.get_size()), (0, 0))

        self.Game.assets.fonts['large'].render(display, f"{self.Game.clock.get_fps():.0f} fps", (20, 20))

        frame_tex = self.Game.surf_to_texture(display)
        frame_tex.use(0)
        self.Game.render.render(mode=moderngl.TRIANGLE_STRIP)

        pg.display.flip()
        frame_tex.release()
