# Atlanpolis

​Step into the sandals of Poseidon, the revered God of the Sea, and embrace the role of a valiant rescuer in "Poseidon's Lifeline"!, your task is clear: Save as many lives as possible by swiftly transporting stranded individuals to safety, one bubble of air at a time.

Game made for the Pygame Community Summer Jam 2023 with the themes: Waterworld/water,  and Chellenge: Small.​

### *Controls*
- Move: arrows
- Grab: x

### Dependecies
```
pygame-ce = "^2.3.0"
moderngl = "^5.8.2"
```
