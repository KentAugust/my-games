# py-western-shooter-game
Western Shooter game made in python with pygame. This project is for "Learn Python by making games" course by Christian Koch

<p align="center">
<img src="repo_img/game_capture.png" width="70%">
</p>

## Enemies
* Cactus: shoot from long distance
* Coffin: hit you with a shovel

<p align="center">
<img src="repo_img/game_capture_2.png" width="70%">
</p>

* Controable with the WASD keys.
* Shoot with "Space" key.
