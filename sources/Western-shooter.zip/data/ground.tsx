<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.6" name="ground" tilewidth="64" tileheight="64" tilecount="248" columns="31">
 <image source="../graphics/tilesets/ground.png" width="1984" height="512"/>
</tileset>
