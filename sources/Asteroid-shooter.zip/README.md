# py-asteroid-shooter-game
Asteroid Shoter game made in python with pygame. This project is for "Learn Python by making games" course by Christian Koch

<p align="center">
<img src="repo_img/game_capture.png" width="70%">
</p>

* The ship is controable with the arrows keys.
* Shoot with "S" key.


