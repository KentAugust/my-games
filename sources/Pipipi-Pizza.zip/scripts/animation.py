import pygame as pg


class Animation:
    def __init__(self, name: str, frames_data: list[tuple[pg.Surface, int]], flip_x: bool = False, flip_y: bool = False) -> None:
        f_data = []
        for frame in frames_data:
            f_data.append((pg.transform.flip(frame[0], flip_x, flip_y), frame[1]))
        self.name = name
        self.frames_data = f_data
        self.start = pg.time.get_ticks()
        self.frame = 0

    def get_frame(self) -> tuple[pg.Surface, int]:
        end = pg.time.get_ticks()
        if end - self.start> self.frames_data[self.frame][1]:
            self.frame += 1
            if self.frame >= len(self.frames_data):
                self.frame = 0
            self.start = pg.time.get_ticks()
        return self.frames_data[self.frame][0], self.frame