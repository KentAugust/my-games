from typing import Any, Protocol


class Game(Protocol):
    __slots__ = ['config','static_textures', 'animated_textures', 'previus_scene']

    def get_mouse_pos(self, display_size: tuple[int, int], scale: bool = False) -> tuple[int, int]:
        ...

    def change_scene(self, scene_key: str, new_args: list[Any] | None = None, keep=True):
        ...
    
    def update_win_size(self, size: tuple[int, int], flags: int = 0):
        ...
    
    def toggle_fullscreen(self, size: tuple[int, int]):
        ...
    
    def exit(self):
        ...
