from typing import Protocol
import pygame as pg


class Sprite(Protocol):
    image: pg.Surface
    hitbox_surf: pg.Surface
    hitbox: pg.FRect
    rect: pg.Rect