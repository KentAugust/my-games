from typing import Protocol
import pygame as pg


class Entity(Protocol):
    image: pg.Surface
    hitbox: pg.FRect
    rect: pg.Rect
    def update(self, dt: float, rect_list: list[pg.Rect | pg.FRect]):
        ...

    def collision_test(self, rect_list: list[pg.Rect | pg.FRect]) -> list[pg.Rect | pg.FRect]:
        ...
    
    def horizontal_collision(self, hit_rects: list[pg.Rect | pg.FRect]) -> None:
        ...

    def vertical_collision(self, hit_rects: list[pg.Rect | pg.FRect]) -> None:
        ...

    def horizontal_movement(self, dt: float) -> None:
        ...

    def vertical_movement(self, dt: float) -> None:
        ...
    
    def spawn_particle(self, surf: pg.Surface, *groups):
        ...
    
    def spawn_coin(self,*args, **kwargs):
        ...
