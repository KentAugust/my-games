from typing import Protocol


class Scene(Protocol):
    def handle_events(self):
        ...
        
    def update(self, *args, **kwargs):
        ...

    def render(self, display):
        ...
