import pygame as pg


class Particle(pg.sprite.Sprite):
    def __init__(
            self, 
            surf: pg.Surface, 
            pos: tuple[float, float],
            velocity: pg.Vector2,
            time: float,
            *groups
        ) -> None:
        super(Particle, self).__init__(*groups)

        self.image = surf
        size = self.image.get_size()
        self.hitbox = pg.FRect(pos[0]-size[0]//2, pos[1]-size[1]//2, *self.image.get_size())
        self.rect: pg.Rect = self.image.get_rect(center=self.hitbox.center)

        self.hitbox_surf = pg.Surface(self.hitbox.size).convert()
        self.hitbox_surf.set_colorkey((0, 0, 0))
        pg.draw.rect(self.hitbox_surf, (40, 220, 40), (0, 0, *self.hitbox.size), 1)

        # movement
        self.velocity = velocity

        self.time = time
        self.start = pg.time.get_ticks()
        

    def update(self, dt, *args, **kwargs):
        self.hitbox.centerx +=  self.velocity.x * dt * dt
        self.hitbox.centery +=  self.velocity.y * dt * dt
        self.rect.centerx = round(self.hitbox.centerx)
        self.rect.centery = round(self.hitbox.centery)
        if pg.time.get_ticks() - self.start > self.time:
            self.kill()
