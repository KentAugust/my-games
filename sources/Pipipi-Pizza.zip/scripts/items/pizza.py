import pygame as pg

from .particle import Particle


class Pizza(Particle):
    def __init__(
            self, 
            surf: pg.Surface, 
            pos: tuple[float, float],
            direction: pg.Vector2,
            speed: float,
            time: float,
            *groups
        ) -> None:
        super(Pizza, self).__init__(surf, pos, direction.copy(), time, *groups)

        # movement
        self.speed = speed

        # sound
        self.crunch_sound = pg.mixer.Sound('assets/sfx/crunch_3.ogg')
        self.crunch_sound.set_volume(0.1)


    def update(self, dt, *args, **kwargs):
        self.hitbox.x +=  self.velocity.x * self.speed * dt
        self.hitbox.y +=  self.velocity.y * self.speed * dt
        self.rect.centerx = round(self.hitbox.centerx)
        self.rect.centery = round(self.hitbox.centery)
        if pg.time.get_ticks() - self.start > 1300:
            self.despawn()

    def collision_test(self, rect_list: list[pg.Rect | pg.FRect]) -> list[pg.Rect | pg.FRect]:
        hit_list = []
        for rect in rect_list:
            if self.hitbox.colliderect(rect):
                hit_list.append(rect)
        return hit_list

    def despawn(self):
        self.crunch_sound.play()
        self.kill()
