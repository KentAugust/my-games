import logging
import pygame as pg

from . import utils
from .interfaces import Game
from .ui import Button


logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)


class Menu:
    def __init__(self, game: Game, canvas_size) -> None:
        self.game = game
        self.canvas = pg.Surface(canvas_size).convert()
        self.scale_mouse = True
    
    def clean(self):
        self.canvas.fill((40, 40, 90))


class MainMenu(Menu):
    config = utils.load_toml('data/scenes.toml')['main']
    def __init__(self, game: Game) -> None:
        super(MainMenu, self).__init__(game, self.config['display_size'])
        self.screen_size = self.config['display_size']

        # backgroun and logo
        self.bg_surf = self.game.static_textures['menu_logo_bg']
        self.logo_surf = self.game.static_textures['logo']
        
        self.play_btn = Button(self.game.static_textures['play_btn'], (self.screen_size[0]//2 - 215, self.screen_size[1]//2 ))
        self.controls_btn = Button(self.game.static_textures['controls_btn'], (self.screen_size[0]//2 - 215, self.screen_size[1] - self.screen_size[1]//3))
        self.credits_btn = Button(self.game.static_textures['credits_btn'], (self.screen_size[0]//2 - 215, self.screen_size[1] - self.screen_size[1]//6))

    def handle_events(self):
        for event in pg.event.get():
            match event.type:
                case pg.QUIT:
                    self.game.exit()
                case pg.KEYDOWN:
                    match event.key:
                        case pg.K_ESCAPE:
                            self.game.exit()
                        case pg.K_F12:
                            self.game.toggle_fullscreen(self.config['display_size'])
                            self.screen_size = self.config['display_size']
                            self.play_btn.change_pos(( self.screen_size[0]//2 - 215, self.screen_size[1]//2 ))
                            self.controls_btn.change_pos(( self.screen_size[0]//2 - 215, self.screen_size[1] - self.screen_size[1]//3 ))
                            self.credits_btn.change_pos(( self.screen_size[0]//2 - 215, self.screen_size[1] - self.screen_size[1]//6 ))
                            # self.scale_mouse = not self.scale_mouse

    def update(self, dt: float):
        pos = self.game.get_mouse_pos(self.config['display_size'], self.scale_mouse)
        self.play_btn.update(pos)
        self.controls_btn.update(pos)
        self.credits_btn.update(pos)

        match self.play_btn.state:
            case 'click':
                self.game.change_scene('transition_level', keep=False)
 
        match self.controls_btn.state:
            case 'click':
                self.game.change_scene('controls', ['main'])

        match self.credits_btn.state:
            case 'click':
                self.game.change_scene('credits', ['main'])
    
    def render(self, display: pg.Surface):
        self.clean()
        self.canvas.blit(self.bg_surf, (0, 0))
        self.play_btn.self_blit(self.canvas)
        self.controls_btn.self_blit(self.canvas)
        self.credits_btn.self_blit(self.canvas)
        pg.transform.smoothscale(self.canvas, display.get_size(), display)


class SettingsMenu(Menu):
    config = utils.load_toml('data/scenes.toml')['main']

    def __init__(self, game: Game, previus_scene_key: str, render_previus: bool = False, update_previus: bool = False) -> None:
        super(SettingsMenu, self).__init__(game, self.config['display_size'])
        self.previus_scene_key = previus_scene_key
        self.render_previus = render_previus
        self.update_previus = update_previus

        self.screen_size = self.config['display_size']
        self.canvas.set_colorkey((0, 0, 0))

        # backgroun and logo
        self.bg_surf = self.game.static_textures['menu_bg']
        self.logo_surf = pg.transform.scale_by(self.game.static_textures['logo'], 0.3)
        self.logo_size = self.logo_surf.get_size()

        self.back_btn = Button(self.game.static_textures['back_btn'], (25, 25))

    def handle_events(self):
        for event in pg.event.get():
            match event.type:
                case pg.QUIT:
                    self.game.exit()
                case pg.KEYDOWN:
                    match event.key:
                        case pg.K_ESCAPE:
                            self.game.exit()
                        case pg.K_F12:
                            self.game.toggle_fullscreen(self.config['display_size'])
                        case pg.K_1:
                            self.game.change_scene(self.previus_scene_key)

    def update(self, dt: float):
        if self.update_previus :
            self.game.previus_scene.update(dt)

        pos = self.game.get_mouse_pos(self.config['display_size'], self.scale_mouse)
        self.back_btn.update(pos)

        match self.back_btn.state:
            case 'click':
                self.game.change_scene(self.previus_scene_key)
    
    def render(self, display: pg.Surface):
        self.clean()
        if self.render_previus:
            self.game.previus_scene.render(self.canvas)
        self.canvas.blit(self.logo_surf, (self.screen_size[0]//2 - self.logo_size[0]//2, self.screen_size[1]//12))
        self.back_btn.self_blit(self.canvas)
        pg.transform.scale(self.canvas, display.get_size(), display)


class Credits(SettingsMenu):
    config = utils.load_toml('data/scenes.toml')['main']

    def __init__(self, game: Game, previus_scene_key: str, update_previus: bool = False) -> None:
        super(Credits, self).__init__(
            game, 
            previus_scene_key, 
            False, 
            update_previus
        )

        self.initialize_credits()

    def initialize_credits(self):
        fonts: list[pg.Font] = [
            pg.font.SysFont('serif', 48, True, False),
            pg.font.SysFont('serif', 32, True, False),
            pg.font.SysFont('serif', 24, False, True)
        ]
        screen_size = self.config['display_size']

        self.credits_titles = []
        titles = [
            ('Credits', 0, (109, 141, 138)),
            ('Development & Art', 1, (203, 129, 117)),
            ('Kent August', 2, (101, 80, 87)),
            # ('Art', 1, (203, 129, 117)), 
            # ('Kent August', 2, (101, 80, 87)),
            ('Music & Sounds', 1, (203, 129, 117)),
            ('Tarantella Napoletana', 2, (101, 80, 87))
        ]
        for i, data in enumerate(titles):
            surf = fonts[data[1]].render(data[0], False, data[2]) 
            size =  surf.get_size()
            pos = (screen_size[0]//2 - size[0]//2, 175 + 75 * (i+1))
            self.credits_titles.append((surf, pos))

    def handle_events(self):
        for event in pg.event.get():
            match event.type:
                case pg.QUIT:
                    self.game.exit()
                case pg.KEYDOWN:
                    match event.key:
                        case pg.K_ESCAPE:
                            self.game.exit()
                        case pg.K_F12:
                            self.game.toggle_fullscreen(self.config['display_size'])
                        case pg.K_1:
                            self.game.change_scene(self.previus_scene_key)

    def update(self, dt: float):
        return super().update(dt)
    
    def render(self, display: pg.Surface):
        self.clean()
        self.canvas.blit(self.bg_surf, (0, 0))
        self.canvas.fblits(self.credits_titles)
        self.canvas.blit(self.logo_surf, (self.screen_size[0]//2 - self.logo_size[0]//2, self.screen_size[1]//12))
        self.back_btn.self_blit(self.canvas)
        pg.transform.scale(self.canvas, display.get_size(), display)


class Controlls(SettingsMenu):
    config = utils.load_toml('data/scenes.toml')['main']

    def __init__(self, game: Game, previus_scene_key: str, update_previus: bool = False) -> None:
        super(Controlls, self).__init__(
            game, 
            previus_scene_key, 
            False, 
            update_previus
        )
        self.bg_surf = self.game.static_textures['controlls_bg']

    def handle_events(self):
        for event in pg.event.get():
            match event.type:
                case pg.QUIT:
                    self.game.exit()
                case pg.KEYDOWN:
                    match event.key:
                        case pg.K_ESCAPE:
                            self.game.exit()
                        case pg.K_F12:
                            self.game.toggle_fullscreen(self.config['display_size'])
                        case pg.K_1:
                            self.game.change_scene(self.previus_scene_key)

    def update(self, dt: float):
        return super().update(dt)
    
    def render(self, display: pg.Surface):
        self.clean()
        self.canvas.blit(self.bg_surf, (0, 0))
        self.canvas.blit(self.logo_surf, (self.screen_size[0]//2 - self.logo_size[0]//2, self.screen_size[1]//12))
        self.back_btn.self_blit(self.canvas)
        pg.transform.scale(self.canvas, display.get_size(), display)
