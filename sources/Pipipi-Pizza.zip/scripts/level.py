import random
import pygame as pg

from . import utils
from .interfaces import Game, Entity
from .camera import Camera
from .entities import Player, Npc, Forniture
from .items import Particle


class Level:
    config = utils.load_toml('data/scenes.toml')['level']
    entities_config = utils.load_toml('data/entities.toml')

    def __init__(self, game: Game) -> None:
        self.game = game
        self.canvas = pg.Surface(self.config['display_size']).convert()
        self.clean()

        self.scale_mouse = True
        self.debug = False

        size = self.config['display_size']
        self.font = pg.font.SysFont('serif', 64, True, True) # .Font('italic')
        self.timer_surf = self.font.render('60', False, (101, 80, 87))
        self.timer_rect = self.timer_surf.get_rect(center=(size[0]//2, 50))

        self.cam = Camera(self.config['display_size'])
        self.entities_gp = pg.sprite.Group()
        self.forniture_gp = pg.sprite.Group()
        self.pizza_gp = pg.sprite.Group()
        self.particle_gp = pg.sprite.Group()

        self.player = Player(
            self.game.animated_textures['player'], 
            self.entities_config['player']['hitbox'],
            self.entities_config['player']['acceleration'],
            self.entities_config['player']['friction'],
            'idle',
            self.spawn_tomato,
            self.cam
        )

        self.spawn_npc(30)
    
        # ui
        self.jar_surf = self.game.static_textures['jar']
        self.jar_rect = self.jar_surf.get_rect(bottomleft=(25, size[1] - 25))

        # music
        self.music = pg.mixer.Sound('assets/music/Faster_Version-2021-05-07_-_Tarantella_-_www.FesliyanStudios.com.mp3')
        self.music.set_volume(0.1)
        self.music.play(loops = -1)

        self.score = 0

        # forniture
        self.init_walls()
        self.init_forniture(40)

        # play time
        self.play_time = 61
        self.start = pg.time.get_ticks()
        self.paticle_start = pg.time.get_ticks()
    
    def init_walls(self):
        size = self.config['display_size']
        Forniture(self.game.static_textures['wall_left'], (0-50, 0, 50, size[1]), self.cam, self.forniture_gp) # left
        Forniture(self.game.static_textures['wall_left'], (0-50, size[1], 50, size[1]), self.cam, self.forniture_gp) # left

        Forniture(self.game.static_textures['wall_right'], (size[0]*2, 0, 50, size[1]), self.cam, self.forniture_gp) # right
        Forniture(self.game.static_textures['wall_right'], (size[0]*2, size[1], 50, size[1]), self.cam, self.forniture_gp) # right

        Forniture(self.game.static_textures['wall_top'], (0, 0 - 50, size[0], 50), self.cam, self.forniture_gp) # top
        Forniture(self.game.static_textures['wall_top'], (size[0], 0 - 50, size[0], 50), self.cam, self.forniture_gp) # top

        Forniture(self.game.static_textures['wall_bottom'], (0, size[1]*2, size[0], 50), self.cam, self.forniture_gp) # bottom
        Forniture(self.game.static_textures['wall_bottom'], (size[0], size[1]*2, size[0], 50), self.cam, self.forniture_gp) # bottom

    def init_forniture(self, count: int) -> None:
        size = self.config['display_size']
        for i in range(count):
            surf = self.game.static_textures[random.choice(['green_table', 'orange_table', 'chair'])]
            surf_size = surf.get_size()
            x = random.randint(80, size[0]*2 - 80)
            y = random.randint(80, size[1]*2 - 80)
            Forniture(surf, (x, y, *surf_size), self.cam, self.forniture_gp) # left

    def spawn_npc(self, count: int):
        size = self.config['display_size']
        for i in range(count):
            hitbox = self.entities_config['npc']['hitbox']
            x = random.randint(80, size[0]*2 - 80)
            y = random.randint(80, size[1]*2 - 80)
            Npc(
                self.game.animated_textures['woman'], 
                (x, y, hitbox[2], hitbox[3]),
                self.entities_config['npc']['acceleration'],
                self.entities_config['npc']['friction'],
                'run',
                self.spawn_coins,
                self.spawn_tomato,
                self.cam, self.entities_gp
            )

    def handle_events(self):
        for event in pg.event.get():
            match event.type:
                case pg.QUIT:
                    self.game.exit()
                case pg.KEYDOWN:
                    match event.key:
                        case pg.K_ESCAPE:
                            self.game.exit()
                        case pg.K_F12:
                            self.game.toggle_fullscreen(self.config['display_size'])
                            self.scale_mouse = not self.scale_mouse
                        case pg.K_F3:
                            self.debug = not self.debug
                        # case pg.K_1:
                        #     self.music.stop()
                        #     self.game.change_scene('main', keep=False)
                        case pg.K_BACKSPACE:
                            self.game.change_scene('controls', ['play'])
                        case pg.K_SPACE:
                            self.player.throw(
                                self.game.static_textures['pizza'],
                                self.cam, self.pizza_gp, self.particle_gp # groups
                            )
    
    def update(self, dt):
        time = (pg.time.get_ticks() - self.start) * 0.001 + 1

        size = self.config['display_size']
        self.timer_surf = self.font.render(f'{self.play_time - time:.0f}', False, (101, 80, 87))
        self.timer_rect = self.timer_surf.get_rect(center=(size[0]//2, 50))

        if time > self.play_time:
            self.music.stop()
            self.game.change_scene('transition_level', [self.score, 'main'], keep=False)

        rects = self.get_rects_from_gp(self.forniture_gp)
        self.cam.update(dt, rects)
        self.pizza_collision()
        self.cam.follow(self.player, 0.06)
    
    def render(self, display: pg.Surface):
        self.clean()
        self.cam.render(self.canvas)
        if self.debug:
            self.cam.render_hitbox(self.canvas, self.cam)
        self.canvas.fblits([(self.timer_surf, self.timer_rect), (self.jar_surf, self.jar_rect)])
        pg.transform.scale(self.canvas, display.get_size(), display)

    def clean(self):
        self.canvas.fill((246, 237, 205))

    def get_rects_from_gp(self, group: pg.sprite.Group) -> list[pg.FRect]:
        rects = []
        for sprite in group.sprites():
            rects.append(sprite.hitbox)
        return rects

    def spawn_coins(self, entity: Entity):
        entity.spawn_coin(self.game.static_textures['coin'], self.cam, self.particle_gp)

    def spawn_tomato(self, entity: Entity, particle: str):
        entity.spawn_particle(self.game.static_textures[particle], self.cam, self.particle_gp)

    def pizza_collision(self):
		# entity pizza collision
        pizza_rects = self.get_rects_from_gp(self.pizza_gp)
        for entity in self.entities_gp.sprites():
            if len(entity.collision_test(pizza_rects)) >= 1:
                self.score += 1 if entity.state != 'eaten' else 0
                entity.change_state('eaten')


class Transitionlevel:
    config = utils.load_toml('data/scenes.toml')['level']
    entities_config = utils.load_toml('data/entities.toml')

    def __init__(self, game: Game, score: int, next_scene_key: str) -> None:
        self.game = game
        self.canvas = pg.Surface(self.config['display_size']).convert()
        self.clean()
        self.score = score
        self.next_scene_key = next_scene_key

        self.font = pg.font.SysFont('serif', 64, True, True)
        self.score_surf = self.font.render(f'x  {self.score}', True, (246, 237, 205))

        self.player = Player(
            self.game.animated_textures['player'], 
            self.entities_config['player']['hitbox'],
            self.entities_config['player']['acceleration'],
            self.entities_config['player']['friction'],
            'idle'
        )
        self.pizza_surf = self.game.static_textures['jar']

        size = self.config['display_size']
        self.items = [
            (self.player.image, (size[0]//2 - self.player.image.get_width()//2, size[1]//4 - self.player.image.get_height()//2)), # type: ignore
            (self.pizza_surf, (size[0]//2 - self.pizza_surf.get_width() - 20, size[1]//2 - self.pizza_surf.get_height() + 45)),
            (self.score_surf, (size[0]//2, size[1]//2 - self.score_surf.get_height()//2))
        ]

        self.scene_start = pg.time.get_ticks()

    def handle_events(self):
        for event in pg.event.get():
            match event.type:
                case pg.QUIT:
                    self.game.exit()
                case pg.KEYDOWN:
                    match event.key:
                        case pg.K_ESCAPE:
                            self.game.exit()
                        case pg.K_F12:
                            self.game.toggle_fullscreen(self.config['display_size'])
    
    def update(self, *args, **kwargs):
        if (pg.time.get_ticks() - self.scene_start) * 0.001 + 1 > 3:
            self.game.change_scene(self.next_scene_key, keep=False)
        
        self.player.play_animation()
        size = self.config['display_size']
        self.items = [
            (self.player.image, (size[0]//2 - self.player.image.get_width()//2, size[1]//4 - self.player.image.get_height()//2)), # type: ignore
            (self.pizza_surf, (size[0]//2 - self.pizza_surf.get_width() - 20, size[1]//2 - self.pizza_surf.get_height() + 45)),
            (self.score_surf, (size[0]//2, size[1]//2 - self.score_surf.get_height()//2))
        ]
    
    def render(self, display: pg.Surface):
        self.clean()
        self.canvas.fblits(self.items)
        pg.transform.scale(self.canvas, display.get_size(), display)
    
    def clean(self):
        self.canvas.fill((101, 80, 87))
