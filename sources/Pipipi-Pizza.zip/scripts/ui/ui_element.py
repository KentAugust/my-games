import pygame as pg

from typing import Optional


class UiElement:
    image: pg.Surface
    def __init__(self, surf: pg.Surface, pos: tuple[float, float]) -> None:
        self.image = surf
        self.rect = self.image.get_rect(topleft=pos)
        self.states = []
        self.state = None

    def change_pos(self, pos: tuple[int, int]):
        self.rect = self.image.get_rect(topleft=pos)

    def self_blit(self, dest: pg.Surface, area: Optional[pg.Rect] = None, special_flags: int = 0):
        return dest.blit(self.image, self.rect, area, special_flags)
    
    def change_state(self, state: str):
        if state not in self.states:
            return
        self.state = state

    def add_state(self, state: str):
        if state in self.states:
            return
        self.states.append(state)

    def __str__(self) -> str:
        return f'{self.__class__.__name__}{self.rect.x, self.rect.y, self.rect.w, self.rect.h}'
