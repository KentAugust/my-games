import pygame as pg

from .ui_element import UiElement


class Button(UiElement):
    def __init__(self, surf: pg.Surface, pos: tuple[float, float]) -> None:
        super().__init__(surf, pos)
        self.add_state('hover')
        self.add_state('click')
        self.add_state('unclick')
        self.change_state('unclick')

    def update(self, mouse_pos: tuple[int, int]):
        if self.rect.collidepoint(*mouse_pos):
            self.change_state('hover')
            if pg.mouse.get_pressed()[0]:
                self.change_state('click')
        else:
            self.change_state('unclick')

