import tomllib

from pathlib import Path

def load_toml(path: str) -> dict:
    n_path = Path(path)
    with open(n_path, mode="rb") as fp:
        data = tomllib.load(fp)
    return data
