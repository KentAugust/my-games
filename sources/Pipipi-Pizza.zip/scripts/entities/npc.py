import random
import pygame as pg

from typing import Callable
from scripts.items import Particle
from . import Entity


class Npc(Entity):
    def __init__(
            self, 
            animations: dict[str, list[tuple[pg.Surface, int]]], 
            hitbox: tuple[float, float, int, int],
            acc: float = 0.2,
            friction: float = -0.1,
            initial_state: str = 'idle',
            coin_particle_func: Callable | None  = None,
            spaw_particle_func: Callable | None  = None,
            *groups
        ) -> None:
        super().__init__(animations, hitbox, acc, friction, initial_state, coin_particle_func, *groups)
        self.activate_death = False

        self.particle_func = spaw_particle_func
        self.changex_start = pg.time.get_ticks()
        self.changey_start = pg.time.get_ticks()

        # sounds
        self.eaten_sound = pg.mixer.Sound('assets/sfx/cartoon_laugh_8.ogg')
        self.eaten_sound.set_volume(0.08)
        self.coin_sound = pg.mixer.Sound('assets/sfx/coin_1.ogg')
        self.coin_sound.set_volume(0.08)

    def spawn_coin(self, surf: pg.Surface, *groups):
        Particle(
                surf,
                (random.randint(int(self.hitbox.left), int(self.hitbox.right)), self.hitbox.bottom),
                pg.Vector2(random.randint(-200, 200)/8-1, random.randint(-200, 200)/8-1),
                500,
                *groups # groups
            )

    def play_animation(self):
        self.image, frame = self.current_animation.get_frame()
        if self.state == 'eaten' and frame == len(self.current_animation.frames_data) - 1:
            self.activate_death = True
            self.eaten_sound.play(0)
            self.coin_sound.play(3)
            if self.spaw_particle_func:
                self.spaw_particle_func(self)
        elif self.state == 'eaten' and frame == 0 and self.activate_death:
            self.kill()

    def particle(self, surf: pg.Surface, *groups):
        if pg.time.get_ticks() - self.particle_start > 100:
            Particle(
                    surf,
                    (self.hitbox.centerx, self.hitbox.bottom),
                    pg.Vector2(random.randint(-200, 200)/8-1, random.randint(-200, 200)/8-1),
                    100,
                    *groups # groups
                )
            self.particle_start = pg.time.get_ticks()


    def update(self, dt: float, rect_list: list[pg.Rect | pg.FRect] = []):
        if pg.time.get_ticks() - self.changex_start > random.randint(100, 700):
            self.direction.x = random.randint(-1, 1)
            self.changex_start = pg.time.get_ticks()

        if pg.time.get_ticks() - self.changey_start > random.randint(100, 700):
            self.direction.y = random.randint(-1, 1)
            self.changey_start = pg.time.get_ticks()
        
        if self.state == 'run':
            self.velocity.x += self.acc * self.direction.x 
            self.velocity.y += self.acc * self.direction.y
        
        # self.particle_func(self, 'tomato') # type: ignore
        super().update(dt, rect_list)
