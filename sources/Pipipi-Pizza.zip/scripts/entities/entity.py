import random
import pygame as pg

from typing import Callable
from scripts.animation import Animation
from scripts.items import Particle


class Entity(pg.sprite.Sprite):
    def __init__(self,
                animations: dict[str, list[tuple[pg.Surface, int]]],
                hitbox: tuple[float, float, int, int], 
                acc: float = 0.2,
                friction: float = -0.1,
                initial_state: str = 'idle',
                spaw_particle_func: Callable | None  = None,
                *groups
        ) -> None:
        super(Entity, self).__init__(*groups)

        # render staff
        self.animations = animations
        self.state = initial_state
        self.current_animation = Animation(self.state, self.animations[self.state])
        self.image, _ = self.current_animation.get_frame()

        # collisions
        self.hitbox = pg.FRect(*hitbox)
        self.rect: pg.Rect = self.image.get_rect(center=self.hitbox.center)

        self.hitbox_surf = pg.Surface(self.hitbox.size).convert()
        self.hitbox_surf.set_colorkey((0, 0, 0))
        pg.draw.rect(self.hitbox_surf, (40, 220, 40), (0, 0, *self.hitbox.size), 1)

        # movement
        self.velocity = pg.Vector2()
        self.acc = acc
        self.friction = friction

        self.direction = pg.Vector2(random.choice([-1, 1]), random.randint(-1, 1))

        self.spaw_particle_func = spaw_particle_func
        self.particle_start = pg.time.get_ticks()


    def update(self, dt: float, rect_list: list[pg.Rect | pg.FRect] = []):
        if self.velocity.magnitude() != 0:
            self.velocity.normalize()

        self.horizontal_movement(dt)
        hit_rects = self.collision_test(rect_list)
        self.horizontal_collision(hit_rects)

        self.vertical_movement(dt)
        hit_rects = self.collision_test(rect_list)
        self.vertical_collision(hit_rects)

        self.direction = self.velocity.normalize() if self.velocity.magnitude() != 0 else pg.Vector2(random.choice([-1, 1]), random.randint(-1, 1))
        self.play_animation()

    def change_state(self, state: str):
        if state != self.state:
            self.state = state
            descomposition = self.state.split('_')
            animation = self.animations.get(descomposition[0])
            if animation:
                flip_x = False
                if len(descomposition) > 1:
                    flip_x = True if descomposition[1] == 'left' else False
                self.current_animation = Animation(descomposition[0], animation, flip_x, False)

    def play_animation(self):
        self.image, _ = self.current_animation.get_frame()

    def collision_test(self, rect_list: list[pg.Rect | pg.FRect]) -> list[pg.Rect | pg.FRect]:
        hit_list = []
        for rect in rect_list:
            if self.hitbox.colliderect(rect):
                hit_list.append(rect)
        return hit_list
    
    def horizontal_collision(self, hit_rects: list[pg.Rect | pg.FRect]):
        for rect in hit_rects:
            if self.hitbox.right > rect.left and self.velocity.x > 0:
                self.hitbox.right = rect.left
            if self.hitbox.left < rect.right and self.velocity.x < 0:
                self.hitbox.left = rect.right
            self.rect.centerx = round(self.hitbox.centerx)
            self.velocity.x = 0

    def vertical_collision(self, hit_rects: list[pg.Rect | pg.FRect]):
        for rect in hit_rects:
            if self.hitbox.bottom > rect.top and self.velocity.y > 0:
                self.hitbox.bottom = rect.top
            if self.hitbox.top < rect.bottom and self.velocity.y < 0:
                self.hitbox.top = rect.bottom
            self.rect.centery = round(self.hitbox.centery)
            self.velocity.y = 0

    def horizontal_movement(self, dt: float):
        self.velocity.x += self.velocity.x * self.friction
        self.hitbox.x += self.velocity.x  * dt 
        self.rect.centerx = round(self.hitbox.centerx)

    def vertical_movement(self, dt: float):
        self.velocity.y += self.velocity.y * self.friction
        self.hitbox.y += self.velocity.y * dt
        self.rect.centery = round(self.hitbox.centery)

    def spawn_particle(self, surf: pg.Surface, *groups):
        if pg.time.get_ticks() - self.particle_start > 60:
            Particle(
                    surf,
                    (self.hitbox.centerx, self.hitbox.bottom),
                    pg.Vector2(random.randint(-200, 200)/8-1, random.randint(-200, 200)/8-1),
                    100,
                    *groups # groups
                )
            self.particle_start = pg.time.get_ticks()
