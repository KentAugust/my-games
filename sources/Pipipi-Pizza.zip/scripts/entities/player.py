from math import sqrt
import random
import pygame as pg

from typing import Callable
from scripts.items import Particle, Pizza
from . import Entity


class Player(Entity):
    def __init__(
            self, 
            animations: dict[str, list[tuple[pg.Surface, int]]], 
            hitbox: tuple[float, float, int, int],
            acc: float = 0.2,
            friction: float = -0.1,
            initial_state: str = 'idle',
            spaw_particle_func: Callable | None  = None,
            *groups
        ) -> None:
        super().__init__(animations, hitbox, acc, friction, initial_state, spaw_particle_func, *groups)

        # sound
        self.shoot_sound = pg.mixer.Sound('assets/sfx/bounce_hit_5.ogg')
        self.shoot_sound.set_volume(0.12)

        # shooting
        self.cooldown = 700
        self.shoot_time = pg.time.get_ticks()

    # def spawn_particle(self, surf, count: int, *groups):
    #     Particle(
    #             surf,
    #             (self.hitbox.centerx, self.hitbox.top),
    #             pg.Vector2(random.randint(0, 60)/40-1, -2),
    #             300,
    #             *groups # groups
    #         )

    def throw(self, surf, *groups):
        if pg.time.get_ticks() - self.cooldown > self.shoot_time:
            pos = self.hitbox.centerx + 2 * self.direction.x, self.hitbox.centery + 2 * self.direction.y
            Pizza(surf, pos, self.direction, 20, 700, *groups)
            self.shoot_sound.play()
            self.shoot_time = pg.time.get_ticks()

    def set_idle(self):
        if self.state.endswith('left'):
            self.change_state('idle_left')
        else:
            self.change_state('idle_right')

    def set_run(self):
        if self.state.endswith('left'):
            self.change_state('run_left')
        else:
            self.change_state('run_right')

    def input(self):
        keys = pg.key.get_pressed()
        # horizontal input
        if keys[pg.K_a]:
            self.velocity.x -= self.acc
            self.change_state('run_right')
            self.spaw_particle_func(self, 'leaf') # type: ignore
        elif keys[pg.K_d]:
            self.velocity.x += self.acc
            self.change_state('run_left')
            self.spaw_particle_func(self, 'leaf') # type: ignore
        else:
            self.set_idle()

        # vertical input  
        if keys[pg.K_w]:
            self.velocity.y -= self.acc
            self.set_run()
        elif keys[pg.K_s]:
            self.set_run()
            self.velocity.y += self.acc

        if keys[pg.K_w] or keys[pg.K_s]:
            state = self.state.split('_')[1]
            self.change_state(f'run_{state}')

    def update(self, dt: float, rect_list: list[pg.Rect | pg.FRect] = []):
        self.input()
        super().update(dt, rect_list)
