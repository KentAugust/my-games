import pygame as pg


class Forniture(pg.sprite.Sprite):
    def __init__(self, surf: pg.Surface, hitbox: tuple[float, float, int, int], *groups) -> None:
        super().__init__(*groups)
        self.image = surf
        self.hitbox = pg.FRect(*hitbox)
        self.rect = self.image.get_rect(center=self.hitbox.center)

        self.hitbox_surf = pg.Surface(self.hitbox.size).convert()
        self.hitbox_surf.set_colorkey((0, 0, 0))
        pg.draw.rect(self.hitbox_surf, (40, 220, 40), (0, 0, *self.hitbox.size), 1)

    def update(self, *args, **kwargs):
        pass
