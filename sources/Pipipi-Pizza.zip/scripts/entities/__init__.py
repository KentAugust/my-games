from .entity import Entity
from .player import Player
from .npc import Npc
from .forniture import Forniture
