import pygame as pg

from .interfaces import Sprite


class Camera(pg.sprite.AbstractGroup):
    def __init__(self, screen_size) -> None:
        super(Camera, self).__init__()
        self.screen_size = screen_size
        self.offset = pg.Vector2()

    def follow(self, target: Sprite, inerce: float):
        self.offset.x += (target.hitbox.centerx - self.offset.x - self.screen_size[0]/2) * inerce
        self.offset.y += (target.hitbox.centery - self.offset.y - self.screen_size[1]/2) * inerce

    def render(self, display: pg.Surface):
        for sprite in sorted(self.sprites(), key=lambda sp: sp.hitbox.centery):
            x = round(sprite.rect.x - self.offset.x)
            y = round(sprite.rect.y - self.offset.y)
            display.blit(sprite.image, (x, y))
    
    def render_hitbox(self, display: pg.Surface, group: pg.sprite.Group | pg.sprite.AbstractGroup):
        for sprite in sorted(group.sprites(), key=lambda sp: sp.hitbox.centery):
            x = round(sprite.hitbox.x - self.offset.x)
            y = round(sprite.hitbox.y - self.offset.y)
            # pg.draw.rect(display, (200, 40, 40), (x, y, *sprite.hitbox.size), 1)
            display.blit(sprite.hitbox_surf, (x, y))