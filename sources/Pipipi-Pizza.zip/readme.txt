Pipipi - Pizza!

Do you like pizzas? 

You are a chef who has to throw pizzas to the people who want them. But beware,
it's not as easy as it looks. You have to skate around, dodging obstacles . 

The goal is to give pizza to as many people as possible in 60 seconds. Can you do it?

Game made for the Pygame Community Eastern Jam 2023 with the two themes:
Particle overdose & Silly music/Pastel color palette

Move: wasd
Throw: space
Fullscreen:  f12  *it's buggy, not recomended*
Show Hitboxes for debug: f3

------- This is the game source code of the prototype version -------