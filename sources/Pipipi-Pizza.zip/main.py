import logging
import sys
import pygame as pg
import scripts.utils as utils

from scripts.interfaces import Scene
from scripts.menu import MainMenu, SettingsMenu, Controlls, Credits
from scripts.level import Level, Transitionlevel


logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)


# all scenes
scenes = {
    'main': {'scene': MainMenu, 'args': []},
    'settings': {'scene': SettingsMenu, 'args': []},
    'controls': {'scene': Controlls, 'args': []},
    'credits': {'scene': Credits, 'args': []},
    'play': {'scene': Level, 'args': []},
    'transition_level': {'scene': Transitionlevel, 'args': [0, 'play']},
}


class Main:
    config = utils.load_toml('data/config.toml')

    def __init__(self) -> None:
        pg.init()
        self.config['desktop_sizes'] = pg.display.get_desktop_sizes()

        self.update_win_size(self.config['window_size'], pg.SCALED) # initializin screen
        self.load_textures()

        pg.display.set_icon(self.static_textures['logo'])

        # initializin game state
        initial = 'main'
        self.previus_scene: Scene | None = None
        self.actual_scene: Scene = scenes[initial]['scene'](self, *scenes[initial]['args'])

        # other atributes
        self.clock = pg.time.Clock()
        self.is_fullscreen = False

    def run(self):
        while True:
            self.update_title()
            dt = self.clock.tick(self.config['fps']) * 0.001 * 60
            self.actual_scene.handle_events()
            self.actual_scene.update(dt)
            self.actual_scene.render(self.screen)
            pg.display.update()


    def load_textures(self):
        textures_conf = self.config['textures']
        general_path = textures_conf['general_path']

        self.static_textures = {}
        self.animated_textures = {}
        for texture_type, textures in textures_conf['types'].items():
            # static
            if texture_type == 'static':
                for name, img_file in textures.items():
                    self.static_textures[name] = pg.image.load(general_path + '/' + img_file).convert_alpha()

            # animated
            if texture_type == 'animated':
                for name, animations in textures.items():
                    for animation_name, data in animations.items():
                        if name not in self.animated_textures:
                            self.animated_textures[name] = {}

                        animation_data = []
                        for frame in data:
                            surf = pg.image.load(general_path + '/' + name + '/' + animation_name + '/' + frame[0]).convert_alpha()
                            animation_data.append((surf, frame[1]))

                        self.animated_textures[name][animation_name] = animation_data
    
    def update_title(self):
        pg.display.set_caption(f'{self.config["title"]} v{self.config["version"]} {self.clock.get_fps():.0f} fps')

    def update_win_size(self, size, flags: int = 0):
        self.screen = pg.display.set_mode(size, flags)
        self.config['current_win_size'] = pg.display.get_window_size()
        logger.debug(f'Windown set to {self.config["current_win_size"]}')

    def get_mouse_pos(self, display_size: tuple[int, int], scaled: bool = False) -> tuple[float, float]:
        if not scaled:
            return pg.mouse.get_pos()

        pos = pg.mouse.get_pos()
        return (
            pos[0]* (display_size[0] / self.config['current_win_size'][0]), 
            pos[1]* (display_size[1] / self.config['current_win_size'][1])
        )

    def add_scene(self, id: str, scene: Scene, args=[]):
        if not scenes.get(id):
            scenes[id] = {'scene': scene, 'args': args}
            logger.info(f"Add '{scenes[id]['scene'].__name__}' class with args {args}")
    
    def change_scene(self, scene_key: str, new_args: list | None = None, keep=True):
        scene_dict = scenes.get(scene_key)
        if scene_dict:
            if self.previus_scene and scene_dict['scene'].__name__ == self.previus_scene.__class__.__name__:
                if keep: # save pevius scene
                    self.actual_scene, self.previus_scene = self.previus_scene, self.actual_scene
                    self.update_win_size(self.config['window_size'], self.screen.get_flags()) #update the window size
                    return
            args = new_args if new_args else scene_dict['args'] # update the scene args if new args are passed
            self.previus_scene = self.actual_scene
            self.actual_scene = scene_dict['scene'](self, *args)
            logger.info(f'Change to "{scene_key}" scene with args {args}')

    def toggle_fullscreen(self, size: tuple[int, int]):
        if not self.is_fullscreen:
            self.update_win_size(size, pg.FULLSCREEN | pg.SCALED)
        else:
            self.update_win_size(self.config['window_size'], pg.SCALED)
        self.is_fullscreen = not self.is_fullscreen
        logger.debug(f'Fullscreen set to {self.is_fullscreen}')

    def exit(self):
        pg.quit()
        sys.exit()


if __name__ == '__main__':
    game = Main()
    game.run()
